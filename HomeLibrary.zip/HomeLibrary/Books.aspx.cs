﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Books : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Application["Books"] != null)
        {
            List<Book> listOfBooks = (List<Book>)Application["Books"];
            foreach (Book book in listOfBooks)
            {
                Response.Write(book.Name);
                Response.Write(book.Author);
                Response.Write(book.ISBN);
            }
        }
    }

    protected void removeAllButton_Click(object sender, EventArgs e)
    {
        Application.RemoveAll();
    }
}