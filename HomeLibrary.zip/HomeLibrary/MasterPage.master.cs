﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

        // I intended to manage theme with session in the code below
        // however, I could not find a way to link to the themes using page directive theme property

        //if (Session["Theme"] != null)
        //{
        //    if (Session["Theme"].Equals("dark"))
        //    {
        //        this.Page.Theme = 
        //    }
        //    else
        //    {

        //    }
        //}
    }
}
